Eita... alguém leu o README?

Nome: Mega Man: Dr. Wily's Revenge
Plataforma: GameBoy
Desenvolvedora: Minakuchi Engineering
Ano de Lançamento: 1991
Gênero: Plataforma
Idioma Original: Inglês
Início do projeto: Novembro de 2017
Final do Projeto: 05 de Fevereiro de 2024


Equipe:
Magall - Romhacking, gráficos e tradução
Ajkmetiuk - Agradecimentos especiais


Enredo:
Graças aos esforços de Mega Man, o super-robô criado por Dr. Light, as ambições de Dr. Wily não se concretizaram. A paz tinha regressado ao mundo, mas o Dr. Wily tinha alterado secretamente os robots industriais desenvolvidos pelo Dr. Light. Depois de tudo o que aconteceu, o Dr. Wily não abandonou o seu desejo de dominar o mundo. Para impedir o Dr. Wily de realizar o seu sonho, Mega Man dirigiu-se à cidade.


Detalhes e História do Projeto:
2017... o ano que fiquei fuçando o PO.B.R.E e vi duas traduções bem incompletas e simples desse jogo, e eu tava animado e afim de traduzir algum jogo simples, então decidi ver por que o pessoal penou tanto para esse...
O começo era tudo flores, achei os gráficos, fonte e os textos, então era só colocar a mão na massa e talvez eu teria traduzido esse projeto num só dia. Mas é claro que não foi assim, não é? Nunca é fácil.
Todo meu aprendizado de ponteiros foi por água abaixo, a ROM não possui espaço contínuo, e o jogo se armazena em blocos, criando uma sequência estrutural em vez de ponteiros clássicos, resultando todos os menus em um só bloco. Imagina dar um errinho na tela de game over, e a tela de zeramento é chamada na hora? Aconteceu toda vez. E não havia espaço para organizar.
Pensei em expandir a ROM, mas não valia mais nenhum minuto de esforço pro projeto, então decidi dropar... por quase 7 anos.
Aleatoriamente no chat com o pessoal, e o denim que vivia trazendo esse meu projeto à tona, acabei conversando o Ajkmetiuk e pedi para ele analisar a ROM e ver se dá pra fazer algum milagre... e acabou dando certo na base da gambiarra.
Depois de lidarmos com essa tela maldita, arregacei as mangas mais uma vez para traduzir todo o resto, adicionando o acento de til, e editando os poucos gráficos que esse jogo possui (e que ninguém editou na época).
Então sim, meus amigos, um jogo que alguns tentaram finalmente possui sua tradução 100% dela, única coisa que contive foi o nome dos ataques e dos inimigos, eu poderia editar, mas tenho zero vontade de inventar nome pras coisas, então fica "sem alma" desse jeito mesmo.


Status da Tradução:
Textos: 100% (Todos os menus traduzidos;)
Gráficos: 100% (ARMA no menu e background feitos;)
Acentos: 100% (Só um acentinho, eu até poderia ter adicionado mais, mas felizmente não precisava;)
Revisão: 100% (Zerado no Gambatte, deve funcionar no resto.)


Agradecimentos:

-Ajkmetiuk, por dar um pontapé final em me animar e ajudar a voltar com o projeto, valeu demais!
-Shadow-Kn e Emuboarding, seja lá quem sejam vocês, ou onde vocês estão, se não tivessem tentado traduzir esse jogo 25 anos atrás, essa tradução nem existiria, belo efeito borboleta, hein?
-O pessoal do Discord, sempre lá enchendo o saco e tretando, mas gosto de vocês, ainda. rsrs
-E a você, por ler esses textões e jogar essa tradução, o jogo é tenso demais, mas espero que gostem, foi feito de coração!


Informações sobre a ROM:

Nome Original: Mega Man - Dr. Wily's Revenge (U) [!].gb (262.144 bytes)
Idioma: Inglês
CRC: 47E70E08

Use o Lunar IPS para aplicar o patch:
https://www.romhacking.net/utilities/240/