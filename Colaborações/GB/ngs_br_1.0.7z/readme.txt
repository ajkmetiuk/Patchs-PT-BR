Nome: Ninja Gaiden Shadow
Plataforma: GameBoy
Desenvolvedora: Natsume co. Ldt / Tecmo
Ano de Lançamento: 1991
Gênero: Plataforma
Idioma Original: Inglês
Início do projeto: 8 de Fevereiro de 2024
Final do Projeto: 14 de Fevereiro de 2024


Equipe:
Magall - Romhacking, gráficos e tradução
Denim - Compressão gráfica
Ajkmetiuk - Agradecimentos especiais


Enredo: 
Baseado em uma versão retrofuturística de 1985, três anos antes do primeiro Ninja Gaiden, o jogador controla Ryu Hayabusa, que deve salvar Nova York das forças do Imperador Garuda, um servo de Jaquio.


Detalhes e História do Projeto:
Dias após a tradução de Mega Man GB, eu tinha outro projeto em mente pelas mesmas circunstâncias que fiz o jogo anterior: um jogo com múltiplas traduções incompletas, e com meu espírito e vontade de querer fazer a melhor tradução desse jogo, resolvi desbravar tamanho desafio.
A primeira tradução foi feita em 1997, umas das primeiras traduções relatadas, feita pelo Hellmatic, onde fez com o conhecimento disponível na época, sem gráficos ou acentos editados, e algumas abreviações. A segunda, em 2007, foi feita por Balboa, que reduziu diversos termos para não parecer abreviado, mas também nunca houve edição gráfica.
Após ver ambas as tentativas, comecei a aprender ASM Patching e busquei um jeito melhor de adaptar os textos, e para me desafiar mentalmente, editei os ponteiros de STAGE para, em vez de usar NIVEL, ATO ou FASE, coloquei um enorme ESTÁGIO só pra ver se eu conseguia, e bom, depois de descobrir que o jogo bizarramente tem os ponteiros no começo da ROM e os blocos de texto são quase no fim de outro banco, tive que fazer um jogo de cintura. Tive ajuda do ajkmetiuk no começo do projeto, mais para aprender melhor como funciona o asm patching, já que fiquei confuso em como adaptar os ponteiros e coordenadas (gameboy tem regras extras, mas nada de outro mundo).
Além disso, o jogo usa ASCII, não precisando de tabela, e em diversos menus o jogo usa espaço para centralizar o texto, então foi ainda mais simples, e ponteiro deixou de ser problema.
Mas então, com o texto resolvido, chegamos no maior desafio: os gráficos.
No GB, os devs geralmente acabam evitando o máximo de compressão possível para economizar processamento e consumo de pilhas... exceto esses que fizeram o jogo. A fonte e gráficos menores (como o menu de VIDA e PAUSA) estão extremamente comprimidos, e o algoritmo de compressão precisa ser bem bolado ou irá corromper outros gráficos (digo isso porque aconteceu hihi), resultado: é realmente muito complexo para um romhacker normal e é por isso que ninguém conseguiu editá-los.
Então se um humano não consegue fazer, peça pros deuses: denim veio ao resgate desse projeto, faltando pouco para o projeto, ele conseguiu descomprimir e já saí voando editar o que precisava ser feito, adicionando uns acentos, mudando o menu e editando a tela cabulosa de FIM, essa acabou interferindo no sprite do chefe final, então o projeto demorou mais uns dias para ser concluído, mas acabou que não foi tão ruim assim, se vocês repararam, o projeto foi feito em menos de uma semana, bem bacana.
Por fim, esse foi um tributo ao romhacking, após 27 anos, tivemos um remake de uma das traduções mais antigas da cena, e tenho orgulho de ter feito ela, acho que hoje ninguém gostaria de fazê-la, então fica uma conquista pessoal.


Status da Tradução:
Textos: 100% (Todos os menus, telas de estágio, cutscene e créditos traduzidos;)
Gráficos: 100% (UI e tela de FIM feita;)
Acentos: 100% (Acentos inseridos após a compressão ter sido lidada, mas usei poucos;)
Revisão: 100% (Não testei a tela de Debug, precisa do Game Genie e não faz parte do jogo em si, mas em geral, zerado no Gambatte, deve funcionar no resto.)


Agradecimentos:

-Ajkmetiuk, por me ajudar no ASM Patching e me animar a fazer outro projeto, obrigado novamente!
-Denim, sempre ao resgate de compressões cabulosas, o jogo finalmente teve seu fim definitivo, aquele obrigado de sempre. rsrs
-Hellmatic e Balboa, suas traduções me chamaram a atenção desse jogo, se tivessem escolhido outra coisa pra fazer, jamais teria essa tradução hoje. hehe
-O pessoal do Discord, aquele apoio moral que sempre existe lá (ou não).
-E a você, por ler esses textões e jogar essa tradução, foi um baita trabalho, mas feito de coração, como sempre!


Informações sobre a ROM:

Nome Original: Ninja Gaiden Shadow (U).gb (131.072 bytes)
Idioma: Inglês
CRC: D3741A3A

Use o Lunar IPS para aplicar o patch:
https://www.romhacking.net/utilities/240/