Nome: Battle Unit Zeoth
Plataforma: GameBoy
Desenvolvedora: 	Jaleco Entertainment
Ano de Lançamento: 1991
Gênero: Shooter
Idioma Original: Inglês
Início do projeto: 27 de Abril de 2026
Final do Projeto: 04 de Maio de 2026

Equipe:
Magall - Romhacking, gráficos e tradução
Ajkmetiuk - Romhacking adicional
Sliter - Tela de Título

Enredo: 
O jogo se passa em um futuro em que a humanidade é invadida por uma raça de robôs alienígenas conhecida como Grein. Há quarenta e dois anos, os humanos da Terra se uniram para repelir a primeira invasão dos alienígenas Grein em uma guerra feroz e sangrenta, mas, ao recuarem, os Grein deixaram para trás uma base subterrânea secreta repleta de máquinas Grein capazes de se autorreplicar.
Dez anos após a vitória da Terra, a base secreta dos Grein foi aberta e uma nova força de ataque dizimou a cidade de Nova Era. Para retaliar, as forças armadas da Terra enviaram um mecha conhecido como Zeoth, especializado em combate contra alienígenas. A missão do Zeoth é deter a força de ataque, entrar na base secreta dos Grein e destruir os ocupantes mecânicos antes que uma nova força invasora chegue.

Detalhes e História do Projeto:
Esse foi um dos jogos aleatórios que acabei encontrando no youtube anos atrás e que fiquei interessado de ver um robô voando por aí atirando em inimigos aleatórios (a premissa é simples, e o jogo é mais simples ainda). Enquanto eu estava lidando com projetos mais complicados, essa foi uma hora como nunca para eu abrir o jogo e ver como é.
Uma parte dos textos e acentos foram fáceis de lidar, mas fiquei confuso em outras telas desse jogo, porém com a ajuda do meu colega de GB ajkmetiuk, descobri alguns textos se comportando como sprites, que felizmente eu já tinha visto em Avenging Spirit, então foi meio caminho andado. Outras adições foi eu traduzir parte desse jogo usando asm (pra não enferrujar), e o ajk me deu uma mão extra para editar os créditos, que foi mais chato que o resto do jogo combinado.
E a cereja do bolo foi editar a tela de título, Sliter editou em pouco tempo e assim, numa semana, estava pronto este projeto maroto. Aproveitem!

Status da Tradução:
100%
(Não preciso entrar em detalhes, todos os textos, gráficos e acentos na qualidade Magall de ser, e foi zerado no Gambatte, aproveitem.)

Agradecimentos:

-Ajkmetiuk, mais um projeto maximizado com sua ajuda, puramente ryco!
-Sliter, valeu pela logo!
-E a você, suas mensagens de apoio me levam a traduzir mais Gameboy!

Informações sobre a ROM:

Nome Original: Battle Unit Zeoth (U) [!].gb (131.072 bytes)
Idioma: Inglês
CRC: E67A92B3

Use o Lunar IPS para aplicar o patch:
https://www.romhacking.net/utilities/240/